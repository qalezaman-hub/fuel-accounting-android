# Fuel Accounting Android Prototype

This is an early Android prototype, not the complete online accounting system. Data persistence, online synchronization, multi-user login/permissions, and full accounting calculations are not yet implemented.

## Build APK using GitHub Actions (phone-friendly)
1. Create a new GitHub repository named `fuel-accounting-android`.
2. Upload the contents of this folder to the repository root (not the parent folder).
3. Open the repository's **Actions** tab and select **Build Android APK**.
4. Tap **Run workflow** if the workflow has not started automatically.
5. When it finishes successfully, open the run, scroll to **Artifacts**, and download `fuel-accounting-debug-apk`. Extract it to get `app-debug.apk`.

This workflow attempts to compile the current prototype. A successful APK build does not mean the full requested accounting features are complete.
