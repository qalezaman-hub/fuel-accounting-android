package com.fuelaccounting.app

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.content.Context

class MainActivity : Activity() {
    private lateinit var body: LinearLayout
    private val prefs by lazy { getSharedPreferences("fuel", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLogin()
    }

    private fun showLogin() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(36,36,36,36)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val title = TextView(this).apply {
            text = "حسابداری تیل‌فروشی"
            textSize = 28f; gravity = Gravity.CENTER
            setPadding(0,0,0,30)
        }
        val user = EditText(this).apply { hint = "نام کاربری"; textSize=18f }
        val pass = EditText(this).apply { hint = "رمز عبور"; textSize=18f }
        val login = Button(this).apply { text = "ورود" }
        login.setOnClickListener {
            if ((user.text.toString()=="admin" && pass.text.toString()=="1234") ||
                (user.text.isNotBlank() && pass.text.isNotBlank())) showDashboard()
            else Toast.makeText(this,"نام کاربری و رمز عبور را وارد کنید",Toast.LENGTH_SHORT).show()
        }
        root.addView(title); root.addView(user); root.addView(pass); root.addView(login)
        setContentView(root)
    }

    private fun showDashboard() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(18,18,18,18)
            layoutDirection=View.LAYOUT_DIRECTION_RTL
        }
        val head=TextView(this).apply {
            text="داشبورد حسابداری تیل‌فروشی"; textSize=24f; gravity=Gravity.CENTER
            setPadding(0,10,0,25)
        }
        root.addView(head)
        val items = listOf(
            "🛒 خرید و تخلیه" to "خرید: ثبت شرکت، نوع تیل، وزن تخلیه، فی تن و کمبود/اضافه.",
            "🚚 فروش و بارگیری" to "فروش بر اساس تن، راننده، پلیت، مشتری، مقصد و فی تن.",
            "📦 موجودی هرات / نیمروز" to "موجودی جداگانه پطرول و دیزل و موجودی بعد از بارگیری.",
            "💵 رسید پول / تصفیه حساب" to "ثبت حواله، مبلغ پرداختی، باقیمانده و ملاحظات.",
            "🏦 حساب صرافی‌ها" to "دریافت و برداشت، ارز USD/AFN/تومان، نرخ دلار و انتقال بین حساب‌ها.",
            "📊 گزارش روزمره" to "خلاصه خرید، فروش، بارگیری، دریافت، پرداخت و موجودی.",
            "👥 کاربران و دسترسی" to "حساب جداگانه برای مشترکین و تعیین بخش‌های قابل مشاهده."
        )
        for ((title, desc) in items) {
            val b=Button(this).apply {
                text="$title\n$desc"; textSize=16f; gravity=Gravity.CENTER_VERTICAL
                setPadding(20,20,20,20)
            }
            b.setOnClickListener { openModule(title) }
            root.addView(b, LinearLayout.LayoutParams(-1,125).apply{setMargins(0,0,0,12)})
        }
        val logout=Button(this).apply{text="خروج"}
        logout.setOnClickListener{showLogin()}
        root.addView(logout)
        scroll.addView(root); setContentView(scroll)
    }

    private fun openModule(title:String) {
        val root=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(20,20,20,20)
            layoutDirection=View.LAYOUT_DIRECTION_RTL
        }
        val back=Button(this).apply{text="← بازگشت"}
        back.setOnClickListener{showDashboard()}
        root.addView(back)
        root.addView(TextView(this).apply{text=title;textSize=25f;setPadding(0,20,0,20)})
        val fields=when {
            title.contains("خرید")->listOf("تاریخ","شرکت: هرات / نیمروز","نوع جنس: دیزل / پطرول","وزن بارگیری","وزن تخلیه","فی تن دلار","مجموع هزینه","کمبود و اضافه")
            title.contains("فروش")->listOf("تاریخ","اسم دریور","نمبر پلیت","مشتری","نوع جنس: دیزل / پطرول","مقدار تن","فی تن دلار","مبلغ کل")
            title.contains("موجودی")->listOf("هرات - پطرول","هرات - دیزل","نیمروز - پطرول","نیمروز - دیزل","موجودی بعد از بارگیری")
            title.contains("رسید")->listOf("تاریخ","آدرس حواله","شماره حواله","به آدرس","مبلغ حواله","مبلغ پرداخت شده","باقیمانده","ملاحظات")
            title.contains("صرافی")->listOf("تاریخ","نام صرافی","نوع عملیات: دریافت / برداشت","ارز: USD / AFN / تومان","مبلغ","فی دلار","معادل دلار","توسط کی","به حساب کی")
            title.contains("گزارش")->listOf("مجموع خرید","مجموع فروش","مجموع بارگیری","دریافت‌ها","پرداخت‌ها","موجودی هرات","موجودی نیمروز")
            else -> listOf("نام کاربری","رمز عبور","سطح دسترسی","اجازه مشاهده خرید","اجازه مشاهده فروش","اجازه مشاهده صرافی","اجازه مشاهده گزارش")
        }
        for (f in fields) root.addView(EditText(this).apply{hint=f;textSize=17f})
        val save=Button(this).apply{text="ذخیره اطلاعات"}
        save.setOnClickListener{Toast.makeText(this,"اطلاعات ثبت شد (نسخه پایه)",Toast.LENGTH_SHORT).show()}
        root.addView(save)
        setContentView(root)
    }
}